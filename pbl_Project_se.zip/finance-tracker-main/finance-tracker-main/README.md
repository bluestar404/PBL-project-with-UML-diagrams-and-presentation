ico is actually being used so do not delete it 
